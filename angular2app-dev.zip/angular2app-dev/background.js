chrome.app.runtime.onLaunched.addListener(function(launchData) {
  chrome.app.window.create('./src/index.html', {
    id: "GDriveExample",
    bounds: {
      width: 12600,
      height: 800
    },
    minWidth: 1260,
    minHeight: 800,
    frame: 'none'
  });
});